// Exercise: Find the top navbar by query for the element type, which is <nav>.
document.getElementsByTagName("nav")[0];
// Exercise: Find the sidebar on the right by using it's id.
document.getElementById('sidebar-right');
// Exercise: Find the "Pages" and "Groups" sections of the sidebar by using their class.
document.getElementsByClassName("pages");
document.getElementsByClassName("groups");
// Exercise: Find all of the comments on the page.

// Exercise: Find the first comment on the page.

// Exercise: Find the last comment on the page.

// Exercise: Find the fourth comment on the page.

// Exercise: Find one of the ads in the sidebar and hide them.

// Exercise: Set the visibility to the form that you hid in the previous step to make it visible again.

// Exercise: Use setAttribute to change src attribute of one of the ads in the sidebar.

// Exercise: Find Sam's post and change it's text to something incredible.

// Exercise: Find the first post and add the .post-liked class to it.

// Exercise: Find the second post and remove the .post-liked class.
